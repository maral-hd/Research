
1. $a = $_POST['inputA'];
2. $b = $_POST['inputB'];
3. if ($a < 12)
   {
4. 	$b = 5;
5. 	$a = a-1; 
   }	
   else
6. 	$b = b+3;
7. if ($a > 7)
   {
8. 	if ($b == 5)
9. 		echo "a\n";
   	else
10.		$b= 7;
   }
11. echo "$b\n";
12. echo "done processing\n";

